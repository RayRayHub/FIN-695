'''
In this program, we simply create a display
of the time and date, and make it animated
so you can see the clock ticking each second

No stock price information yet
This shows you how graphics and animation works 
'''

# import needed modules
from tkinter import *

import arrow
from yahoo_fin import stock_info as si

# create a root window hold all widgets
root = Tk()
#specify the title and size of the root window
root.title("U.S. Stock Market Watch")
root.geometry("1100x750")
# create a first label using hte Label() function
label = Label(text="", fg="Blue", font=("Helvetica", 80))
label.pack()

# create a second label for indexes
label2 = Label(text="", fg="Red", font=("Helvetica", 60))
label2.pack()

# set up tickers and names
tickers = ['^DJI','^GSPC']
names = ['DOW JONES','S&P500']

# define the StockWatch() function

def StockWatch():

    #obtain current date and time infomration         
    tdate=arrow.now().format('MMMM DD, YYYY')
    tm=arrow.now().format('hh:mm:ss A')
    #put the date and time information in the first label         
    label.configure(text=tdate+"\n"+tm) 
    #call the StockWatch() function after 5000 milliseconds
    root.after(1000, StockWatch)

# call the StockWatch() function
StockWatch()  
# run the game loop
root.mainloop()



