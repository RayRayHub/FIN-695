 
def StockPrice(div, g, r):
    P = (div*(1+g)/(r-g))
    return P
