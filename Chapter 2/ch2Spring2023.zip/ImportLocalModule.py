# Make sure you put CreateLocalModule.py in the same folder as this program
from CreateLocalModule import StockPrice
print(StockPrice(2, 0.05, 0.1))
print(StockPrice(1, 0.08, 0.1))
print(StockPrice(2, 0.02, 0.08))

