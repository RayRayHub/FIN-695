mylink = ('&')
strlist = ['University', 'of', 'Kentucky']
JoinedString = mylink.join(strlist)
print(JoinedString)