for n in range(9, 15, 2):
    n=n+1
    print(n)
print('finished')
