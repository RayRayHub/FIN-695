for n in range(3):
    n=n+1
    if n==2:
        print("break the loop")
        pass
    print(n)
print('finished')
